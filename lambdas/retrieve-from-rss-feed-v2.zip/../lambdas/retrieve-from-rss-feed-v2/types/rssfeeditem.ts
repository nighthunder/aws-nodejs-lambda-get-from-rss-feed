interface RssFeedItem{
    title: string;
    link: string;
    content: string;
    pubDate: string;
}

export default RssFeedItem