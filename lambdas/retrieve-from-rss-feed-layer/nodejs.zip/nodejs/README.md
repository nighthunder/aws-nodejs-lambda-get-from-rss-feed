# aws-nodejs-lambda-get-from-rss-feed
Código de lambda AWS para obter dados de um feed 
